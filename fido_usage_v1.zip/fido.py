#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Get talk,SMS,data usage from fido website"""

import argparse
import json
import sys

import requests
import time

# these are gmail credentials to send emails from to users who are 
# trending over the 3GB bandwidth cap, this user will also be CC'd on alters
gmail_user = 'adminuser@gmail.com'
gmail_pwd = 'gmailadminpassword'


def send_email(recipient, subject, body):
    import smtplib
    TO = recipient if type(recipient) is list else [recipient]
    SUBJECT = subject
    TEXT = body
    message = """From: %s\nTo: %s\nSubject: %s\n\n%s
    """ % (gmail_user, ", ".join(TO), SUBJECT, TEXT)
    try:
        server_ssl = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        server_ssl.ehlo() 
        server_ssl.login(gmail_user, gmail_pwd)  
        server_ssl.sendmail(gmail_user, TO, message)
        server_ssl.close()
        print 'successfully sent the mail'
    except:
        print "failed to send mail"


def get_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('-u', '--username', dest='username', required=True,
                        help='username')
    parser.add_argument('-p', '--password', dest='password', required=False,
                        help='fido password')
    parser.add_argument('-i', '--influxdb', dest='influxdb', required=False,
                        action='store_true', help='influxdb format', default=False)

    return parser.parse_args()

class FidoConnection(object):
    """Class to connect and get data from fido"""
    def __init__(self, options):
        self.options = options
        # Header
        self.headers = {}
        self.headers['User-Agent'] = ('Mozilla/5.0 (X11; Linux x86_64; rv:10.0.7) '
                                      'Gecko/20100101 Firefox/10.0.7 Iceweasel/10.0.7')
        # Cookies
        self.cookies = {}
        # Account number
        self.account_number = None
        # Days till next period
        self.daysnextperiod = None
        # Phone number
        self.number = None
        # balance
        self.balance = None
        # fido dollar
        self.fido_dollar = None
        # usage
        self.usage = {}
        # accountOverview
        self.accountOverview = {}
        # data
        self.metrics = {}

    def _authenticate(self):
        """Log in fido website"""
        ##########################################################################################
        url = "https://rogers-fido.janraincapture.com/widget/traditional_signin.jsonp"
        capture = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
        data = {
            "utf8": "✓",
            "capture_screen": "signIn",
            "js_version": "7ce15e1",
            "capture_transactionId": capture,
            "form": "signInForm",
            "flow": "fido",
            "client_id": "bfkecrvys7sprse8kc4wtwugr2bj9hmp",
            "redirect_uri": "https://www.fido.ca/pages/#/",
            "response_type": "token",
            "flow_version": "20160802212911820492",
            "settings_version": "",
            "locale": "en-US",
            "recaptchaVersion": "1",
            "userID": self.options.username,
            "currentPassword": self.options.password,
        }

        raw_res = requests.post(url, headers=self.headers, data=data)

        self.cookies = raw_res.cookies

        ##########################################################################################
        url = "https://rogers-fido.janraincapture.com/widget/get_result.jsonp"
        params = {"transactionId": capture}
        raw_res = requests.get(url, params=params, headers=self.headers, cookies=self.cookies)

        ##print raw_res
        ##wait = input("PRESS ENTER TO CONTINUE.")

        return_data = json.loads(raw_res.text[43:-2])

        if "result" not in return_data or "accessToken" not in return_data['result']:
            print "Error during login"
            sys.exit(1)

        ##########################################################################################
        url = "https://www.fido.ca/pages/api/selfserve/v3/login"
        data = {"accessToken": return_data['result']['accessToken'],
                "uuid": return_data['result']['userData']['uuid'],
               }
        raw_res = requests.post(url, headers=self.headers, data=data)
        self.cookies = raw_res.cookies
        output = raw_res.json()


        try:
            if (output['getCustomerAccounts']['accounts'][0]['status'] == "CLOSED"):
                self.account_number = output['getCustomerAccounts']['accounts'][1]['accountNumber']
            else:
                self.account_number = output['getCustomerAccounts']['accounts'][0]['accountNumber']            
        except (KeyError, IndexError):
            print "Error during login"
            sys.exit(2)
        ##########################################################################################
        url = "https://www.fido.ca/pages/api/selfserve/v2/accountOverview"
        data = {"accountNumber": self.account_number,
                "language": "en",
                "refresh": "false"}
        raw_res = requests.post(url, cookies=self.cookies, data=data, headers=self.headers)
        self.accountOverview = raw_res.json()
        self.number = self.accountOverview['getAccountInfo']['subscriberService'][0]['service'][0]['subscriberNo']
        self.daysnextperiod = self.accountOverview['getAccountInfo']['nextCycleDueIn']
        time.sleep(5)
        raw_res = requests.post(url, cookies=self.cookies, data=data, headers=self.headers)
        self.accountOverview = raw_res.json()
        self.daysnextperiod = self.accountOverview['getAccountInfo']['nextCycleDueIn']

    def get_usage(self):
        """Get usage"""
        usage_url = "https://www.fido.ca/pages/api/selfserve/v1/postpaid/dashboard/usage"
        data = {"ctn": self.number,
                "language": "en",
                "accountNumber": self.account_number}
        raw_res = requests.post(usage_url, cookies=self.cookies, data=data, headers=self.headers)
        self.usage = raw_res.json()

    def prepare_data(self):
        """Read data from usage/balance/fido_dollar"""
        self.metrics = {}
        json_key = 'wirelessUsageSummaryInfoList'
        for mtype in ['used', 'total', 'remaining']:
            # TODO: handle multiple phone number
            # self.usage['data'][0] means the first phone number of your account...
            # How to link phone number to this index ???
            self.metrics['data_' + mtype] = self.usage['data'][0][json_key][0][mtype]
       


    def print_output(self):
        #print json.dumps(self.metrics)
        print self.options.username+'|'+json.dumps(self.metrics['data_used'])+'|'+self.daysnextperiod


        if ((float(json.dumps(self.metrics['data_remaining']))/(981.9093333*float(self.daysnextperiod))) < 100):
          print "calling sending email..."
          send_email([self.options.username,gmail_user],'Fido Data Usage Alert',self.options.username+'. You used '+str(int(round(float(json.dumps(self.metrics['data_used']))/1024)))+'MB. Data remaining '+str(int(round(float(json.dumps(self.metrics['data_remaining']))/1024)))+'MB. '+self.daysnextperiod+' days until next period. You need to limit your usage to '+str(int(round(float(json.dumps(self.metrics['data_remaining']))/(1024*int(self.daysnextperiod)))))+'MB per day, which is '+str(int(round(float(json.dumps(self.metrics['data_remaining']))/(981.9093333*int(self.daysnextperiod)))))+'% of typical spend.'+'\n')
        with open('C:/usage/fido_data.txt', 'a') as outfile:
            outfile.write(self.options.username+'|'+json.dumps(self.metrics['data_used'])+'|'+json.dumps(self.metrics['data_remaining'])+'|'+self.daysnextperiod+'\n')
            print int(round(float(json.dumps(self.metrics['data_used']))/1024))

    def connect(self):
        """Connect to fido website"""
        self._authenticate()


def main():
    """Main function"""
    conn = FidoConnection(get_args())
    conn.connect()
    conn.get_usage()
    conn.prepare_data()
    conn.print_output()

if __name__ == '__main__':
    main()